package com.ryland.puzzlepoint;

import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v4.app.FragmentActivity;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import puzzlepoint.ryland.com.puzzlepoint.R;

public class PlacesActivity extends FragmentActivity implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_places_map);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        mMap.setMyLocationEnabled(true);
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setRotateGesturesEnabled(false);

        // Add a marker for location1 in philly,
        LatLng location1 = new LatLng(40.0961957,-74.9764854);
        Marker m1  = mMap.addMarker(new MarkerOptions().position(location1).title("We Rock the Spectrum-Philly"));
        m1.setTag(location1);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location1, mMap.getCameraPosition().zoom));
        //second location in Bensalem
        LatLng location2 = new LatLng(40.1643238,-75.1545672);
        Marker m2 = mMap.addMarker(new MarkerOptions().position(location2).title("Theraplay-Bensalem"));
        m2.setTag(location2);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location2, mMap.getCameraPosition().zoom));
        //third location
        LatLng location3 = new LatLng(40.0853677,-75.3580568);
        Marker m3 = mMap.addMarker(new MarkerOptions().position(location3).title("Kutest Kids Early Intervention"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location3, mMap.getCameraPosition().zoom));
        //fourth location
        LatLng location4 = new LatLng(40.1544094,-75.1368758);
        Marker m4 = mMap.addMarker(new MarkerOptions().position(location4).title("Abington Speech Pathology"));
        m4.setTag(location4);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location4, mMap.getCameraPosition().zoom));
        //fifth location
        LatLng location5 = new LatLng(40.109541,-75.2096835);
        Marker m5 = mMap.addMarker(new MarkerOptions().position(location5).title("KidsPlayWork Pediatric Occupational Therapy"));
        m4.setTag(location5);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location5, mMap.getCameraPosition().zoom));


    }

    @Override
    public boolean onMarkerClick(final Marker marker) {

        // Retrieve the data from the marker.
        LatLng location = (LatLng) marker.getTag();

        // Check if a click count was set, then display the click count.
        Snackbar.make(findViewById(android.R.id.content), location.toString(), Snackbar.LENGTH_LONG).show();
        // Return false to indicate that we have not consumed the event and that we wish
        // for the default behavior to occur (which is for the camera to move such that the
        // marker is centered and for the marker's info window to open, if it has one).
        return false;
    }
}