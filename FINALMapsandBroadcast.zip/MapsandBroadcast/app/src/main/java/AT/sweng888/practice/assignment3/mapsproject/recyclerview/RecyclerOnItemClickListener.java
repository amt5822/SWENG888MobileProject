package AT.sweng888.practice.assignment3.mapsproject.recyclerview;

import android.view.View;

public interface RecyclerOnItemClickListener {

    void onItemClick(View view, int position);

    void onLongItemClick(View view, int position);
}
