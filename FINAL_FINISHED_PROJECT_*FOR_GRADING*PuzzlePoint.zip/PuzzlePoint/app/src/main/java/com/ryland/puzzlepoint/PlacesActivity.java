package com.ryland.puzzlepoint;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RatingBar;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCanceledListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import puzzlepoint.ryland.com.puzzlepoint.BuildConfig;
import puzzlepoint.ryland.com.puzzlepoint.R;

public class PlacesActivity extends FragmentActivity implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener {

    private static final int REQUEST_STORAGE_PERMISSION_REQUEST_CODE = 2;
    private GoogleMap mMap;
    private SupportMapFragment mapFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_places_map);
        mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);

        if (!checkPermissions()) {
            requestPermissions();
        }else
        {
            mapFragment.getMapAsync(this);
        }
    }

    private boolean checkPermissions() {
        return ((ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED));
    }

    private void startStoragePermissionRequest() {
        ActivityCompat.requestPermissions(PlacesActivity.this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                REQUEST_STORAGE_PERMISSION_REQUEST_CODE);
    }

    // Return the current state of the permissions needed.
    private void showSnackbar(final int mainTextStringId, final int actionStringId,
                              View.OnClickListener listener) {
        Snackbar.make(findViewById(android.R.id.content),
                getString(mainTextStringId),
                Snackbar.LENGTH_INDEFINITE)
                .setAction(getString(actionStringId), listener).show();
    }

    // Callback received when a permissions request has been completed.

    private void requestPermissions() {
        boolean shouldProvideLocationRationale =
                ActivityCompat.shouldShowRequestPermissionRationale(this,
                        Manifest.permission.ACCESS_FINE_LOCATION);

        // Provide an additional rationale to the user.
        if (shouldProvideLocationRationale) {
            Log.i("permission", "Displaying permission rationale to provide additional context.");

            View.OnClickListener listener = new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    startStoragePermissionRequest();
                }
            };
            showSnackbar(R.string.permission_rationale_msg, android.R.string.ok, listener);
        } else {
            Log.i("Permission", "Requesting permission");
            // Request permission.
            startStoragePermissionRequest();
        }
    }

    @SuppressLint({"RestrictedApi", "MissingPermission"})
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == REQUEST_STORAGE_PERMISSION_REQUEST_CODE) {
            if (grantResults.length <= 0) {
                // If user interaction was interrupted, the permission request is cancelled and you
                // receive empty arrays.
                Log.i("permission", "User interaction was cancelled.");
            } else if (grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                // Permission granted.
                mapFragment.getMapAsync(this);
            } else {
                // Permission denied.

                showSnackbar(R.string.permission_denied_explanation, R.string.permission_settings,
                        view ->
                        {
                            // Build intent that displays the App settings screen.
                            Intent intent = new Intent();
                            intent.setAction(
                                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            Uri uri = Uri.fromParts("package",
                                    BuildConfig.APPLICATION_ID, null);
                            intent.setData(uri);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        });
            }
        }
    }


    @SuppressLint("MissingPermission")
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        mMap.setMyLocationEnabled(true);
        mMap.getUiSettings().setZoomControlsEnabled(true);
        mMap.getUiSettings().setRotateGesturesEnabled(false);
        mMap.setOnMarkerClickListener(this);

        // Add a marker for location1 in philly,
        LatLng location1 = new LatLng(40.0961957,-74.9764854);
        Marker m1  = mMap.addMarker(new MarkerOptions().position(location1).title("We Rock the Spectrum-Philly"));
        m1.setTag(location1);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location1, 14));
        //second location in Bensalem
        LatLng location2 = new LatLng(40.1643238,-75.1545672);
        Marker m2 = mMap.addMarker(new MarkerOptions().position(location2).title("Theraplay-Bensalem"));
        m2.setTag(location2);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location2, 14));
        //third location
        LatLng location3 = new LatLng(40.0853677,-75.3580568);
        Marker m3 = mMap.addMarker(new MarkerOptions().position(location3).title("Kutest Kids Early Intervention"));
        m3.setTag(location3);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location3, 14));
        //fourth location
        LatLng location4 = new LatLng(40.1544094,-75.1368758);
        Marker m4 = mMap.addMarker(new MarkerOptions().position(location4).title("Abington Speech Pathology"));
        m4.setTag(location4);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location4, 14));
        //fifth location
        LatLng location5 = new LatLng(40.109541,-75.2096835);
        Marker m5 = mMap.addMarker(new MarkerOptions().position(location5).title("KidsPlayWork Pediatric Occupational Therapy"));
        m5.setTag(location5);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location5, 14));


    }

    @Override
    public boolean onMarkerClick(final Marker marker) {

        // Retrieve the data from the marker.
        LatLng location = (LatLng) marker.getTag();


        showDialog(location);
        // Return false to indicate that we have not consumed the event and that we wish
        // for the default behavior to occur (which is for the camera to move such that the
        // marker is centered and for the marker's info window to open, if it has one).
        return false;
    }

    private void showDialog(LatLng location)
    {
        LayoutInflater factory = LayoutInflater.from(this);
        final View deleteDialogView = factory.inflate(R.layout.rating_dialog, null);
        final AlertDialog deleteDialog = new AlertDialog.Builder(this).create();

        RatingBar ratingBar = deleteDialogView.findViewById(R.id.rating);
        deleteDialog.setView(deleteDialogView);
        deleteDialogView.findViewById(R.id.btnSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //your business logic
                deleteDialog.dismiss();

                MarkerInfo markerInfo = new MarkerInfo(ratingBar.getRating(),location.latitude,location.longitude);


                DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference();

                mDatabase.child("markerRatings").push().setValue(markerInfo).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                        // Check if a click count was set, then display the click count.
                        Snackbar.make(findViewById(android.R.id.content), "Completed", Snackbar.LENGTH_LONG).show();
                    }
                })
                        .addOnCanceledListener(new OnCanceledListener() {
                            @Override
                            public void onCanceled() {

                                // Check if a click count was set, then display the click count.
                                Snackbar.make(findViewById(android.R.id.content), "Cancelled", Snackbar.LENGTH_LONG).show();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                // Check if a click count was set, then display the click count.
                                Snackbar.make(findViewById(android.R.id.content), "Cancelled", Snackbar.LENGTH_LONG).show();
                            }
                        });

                // Check if a click count was set, then display the click count.
                Snackbar.make(findViewById(android.R.id.content), String.valueOf(ratingBar.getRating()), Snackbar.LENGTH_LONG).show();

            }
        });


        deleteDialog.show();
    }
}