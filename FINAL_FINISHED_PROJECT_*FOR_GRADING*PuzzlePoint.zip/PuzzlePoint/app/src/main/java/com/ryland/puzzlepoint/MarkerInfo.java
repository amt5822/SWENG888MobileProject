package com.ryland.puzzlepoint;

public class MarkerInfo
{
    private float rating;
    private double latitude;
    private double longitude;

    public MarkerInfo(float rating, double latitude, double longitude) {
        this.rating = rating;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }
}
